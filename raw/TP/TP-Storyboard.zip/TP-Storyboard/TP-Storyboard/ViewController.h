//
//  ViewController.h
//  TP-Storyboard
//
//  Created by Abdelkader Gouaich on 2/29/12.
//  Copyright (c) 2012 IUT, Université Montpellier 2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    int compteurInterne;
}
@property (weak, nonatomic) IBOutlet UITextField *textArea;
- (IBAction)increment:(id)sender;

@end
