//
//  main.m
//  TP-Storyboard
//
//  Created by Abdelkader Gouaich on 2/29/12.
//  Copyright (c) 2012 IUT, Université Montpellier 2. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
