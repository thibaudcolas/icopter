//
//  GameScene.m
//  SLQTSOR
//
//  Created by Mike Daley on 29/08/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//

#import "GameScene.h"
#import "Image.h"
#import "ImageRenderManager.h"

@implementation GameScene

- (id) init
{
	self = [super init];
	if (self != nil) {
		sharedImageRenderManager = [ImageRenderManager sharedImageRenderManager];
		myImage = [[Image alloc] initWithImageNamed:@"knight.gif" filter:GL_LINEAR];
		myImage.color = Color4fMake(0, 0.5, 0.8, 0.37);
		myImage1 = [[Image alloc] initWithImageNamed:@"knight.gif" filter:GL_LINEAR];
		scaleAmount = 2;
	}
    mvt = CGPointMake(160, 240);
    etatdecx = true;
    etatdecy = true;
	return self;
}



- (void)updateSceneWithDelta:(float)aDelta {
	float xScale = myImage.scale.x + scaleAmount * aDelta;
	float yScale = myImage.scale.y + scaleAmount * aDelta;
	//c pour le zoom
    myImage.scale = Scale2fMake(xScale, yScale);
    
	myImage.rotationPoint = CGPointMake(45 * myImage.scale.x, 15 * myImage.scale.y);
	myImage.rotation = myImage.rotation -= 180 * aDelta;
	if (myImage.scale.x >= 5 || myImage.scale.x <= 2) {
		scaleAmount *= -1;
	}
    //0= increment 1=decrement
    
    if (mvt.x < 320 && etatdecx){
        absx+=7;
    } else {
        
        etatdecx = false;
        if (mvt.x > -100){
            absx-=1;
        }
        else {
            etatdecx = true;
        }
    }
    
    if (mvt.y < 480 && etatdecy){
        absy+=1;
    }else{
        
        etatdecy = false;
        if(mvt.y > 0){
            absy-=1;
        }
        else{
            etatdecy = true;
        }
    }
    
    mvt = CGPointMake(160 + absx, 240 + absy);
	
}


- (void)renderScene {
	[myImage1 renderCenteredAtPoint:CGPointMake(160, 240)];
	[myImage renderCenteredAtPoint:mvt];
	[sharedImageRenderManager renderImages];
    //glTranslatef(0.0,0.1,0.0);
}


@end
