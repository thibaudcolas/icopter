//
//  GameController.m
//  GLGamev2
//
//  Created by Michael Daley on 10/07/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//

#import "GameController.h"
#import "SLQTSORAppDelegate.h"
#import "GameScene.h"
#import "EAGLView.h"

#pragma mark -
#pragma mark Private interface

@interface GameController (Private) 
// Initializes OpenGL
- (void)initGameController;

@end

#pragma mark -
#pragma mark Public implementation

@implementation GameController

@synthesize currentScene;
@synthesize gameScenes;
@synthesize eaglView;

// Make this class a singleton class
SYNTHESIZE_SINGLETON_FOR_CLASS(GameController);

- (void)dealloc {
    [gameScenes release];
	[highScores release];
    [super dealloc];
}

- (id)init {
    self = [super init];
    if(self != nil) {
		
		// Initialize the game
        [self initGameController];
    }
    return self;
}

#pragma mark -
#pragma mark Update & Render

- (void)updateCurrentSceneWithDelta:(float)aDelta {
    [currentScene updateSceneWithDelta:aDelta];
}

-(void)renderCurrentScene {
    [currentScene renderScene];
}

#pragma mark -
#pragma mark Transition

- (void)transitionToSceneWithKey:(NSString*)aKey {
	currentScene = [gameScenes objectForKey:aKey];
	[currentScene transitionIn];
}

#pragma mark -
#pragma mark Orientation adjustment

- (CGPoint)adjustTouchOrientationForTouch:(CGPoint)aTouch {
	
	CGPoint touchLocation = aTouch;
	
	touchLocation.y = 480 - aTouch.y;
	
	return touchLocation;
}

@end

#pragma mark -
#pragma mark Private implementation

@implementation GameController (Private)

- (void)initGameController {

    SLQLOG(@"INFO - GameController: Starting game initialization.");
	
	// Load the game scenes
    gameScenes = [[NSMutableDictionary alloc] init];
	AbstractScene *scene = [[GameScene alloc] init];
	[gameScenes setValue:scene forKey:@"game"];
	[scene release];
    
    // Set the starting scene for the game
    currentScene = [gameScenes objectForKey:@"game"];

	// Initialize the accelerometer
	[[UIAccelerometer sharedAccelerometer] setUpdateInterval:1.0 / 100.0];
	[[UIAccelerometer sharedAccelerometer] setDelegate:currentScene];
	
    SLQLOG(@"INFO - GameController: Finished game initialization.");
}

@end
