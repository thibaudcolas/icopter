//
//  GameScene.h
//  SLQTSOR
//
//  Created by Mike Daley on 29/08/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//

#import "AbstractScene.h"

@class Image;
@class ImageRenderManager;
@class GameController;
@class SoundManager;
@class SpriteSheet;
@class PackedSpriteSheet;
@class Animation;
@class BitmapFont;
@class TiledMap;
@class ParticleEmitter;

@interface GameScene : AbstractScene {

	////////////////////// Singleton references
	GameController *sharedGameController;			// Reference to the game controller
	ImageRenderManager *sharedImageRenderManager;	// Reference to the image render manager
	SoundManager *sharedSoundManager;				// Reference to the sound manager

	////////////////////// Player sprite ivars
	Image *knight;				// Image of a knight to move around with the joypad
	CGPoint knightLocation;		// Location of the knight sprite on the screen
	float directionOfTravel;	// Direction in which to move the player based on the joypad location
	
	////////////////////// Images
	Image *joypad;				// Image of the joypad
	
	////////////////////// Joypad ivars
	CGRect joypadBounds;		// Bounds of the rectangle in which a touch is classed as activating the joypad
	CGPoint joypadCenter;		// Center of the joypad
	CGSize joypadRectangleSize;	// Height and Width of the joypad touch rectangle
	float joypadDistance;		// Distance the joypad has been moved from its center
	int joypadTouchHash;		// Holds the unique hash value given to a touch on the joypad.  
								// This allows us to track the same touch during touchesMoved events
	BOOL isJoypadTouchMoving;	// YES if a touch is being tracked for the joypad
	
	////////////////////// Accelerometer values
	UIAccelerationValue accelerationValues[3];	// Holds the x, y and z accelerometer values
}

@end
