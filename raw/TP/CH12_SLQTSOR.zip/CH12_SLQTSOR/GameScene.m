//
//  GameScene.m
//  SLQTSOR
//
//  Created by Mike Daley on 29/08/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//

#import "GameScene.h"
#import "Image.h"
#import "ImageRenderManager.h"
#import "GameController.h"
#import "SoundManager.h"
#import "SpriteSheet.h"
#import "PackedSpriteSheet.h"
#import "Animation.h"
#import "BitmapFont.h"
#import "TiledMap.h"
#import "ParticleEmitter.h"

@implementation GameScene

- (void)dealloc {
	[super dealloc];
}

- (id) init
{
	self = [super init];
	if (self != nil) {

		// Grab an instance of the render manager
		sharedGameController = [GameController sharedGameController];
		sharedImageRenderManager = [ImageRenderManager sharedImageRenderManager];
		sharedSoundManager = [SoundManager sharedSoundManager];
		
		// Setup the joypad
		joypadCenter = CGPointMake(50, 50);
		joypadRectangleSize = CGSizeMake(40, 40);
		joypadBounds = CGRectMake(joypadCenter.x - joypadRectangleSize.width, 
								  joypadCenter.y - joypadRectangleSize.height, 
								  joypadRectangleSize.width * 2, 
								  joypadRectangleSize.height * 2);
		
		knight = [[Image alloc] initWithImageNamed:@"knight.png" filter:GL_LINEAR];
		knight.scale = Scale2fMake(3, 3);
		knightLocation = CGPointMake(160, 240);
		
		joypad = [[Image alloc] initWithImageNamed:@"joypad.png" filter:GL_LINEAR];
		
	}
	return self;
}



- (void)updateSceneWithDelta:(float)aDelta {
	
	// If the joypad is being moved and the accelerometer is not switch on then update
	// the player based on the joy pad
	if (!sharedGameController.eaglView.uiSwitch.on) {
		knightLocation.x -= (aDelta * (20 * joypadDistance)) * cosf(directionOfTravel);
		knightLocation.y -= (aDelta * (20 * joypadDistance)) * sinf(directionOfTravel);
	}
	
	// If the accelerometer is on then adjust the player based on the accelerometer data
	if (sharedGameController.eaglView.uiSwitch.on) {
		knightLocation.x += aDelta * (accelerationValues[0] * 1000);
		knightLocation.y += aDelta * (accelerationValues[1] * 1000);
	}
	
	// Stop the player moving beyond the bounds of the screen
	if (knightLocation.x < 0)
		knightLocation.x = 0;
	if (knightLocation.x > 320)
		knightLocation.x = 320;
	if (knightLocation.y < 0)
		knightLocation.y = 0;
	if (knightLocation.y > 480)
		knightLocation.y = 480;
}


- (void)renderScene {

	// Clear the screen
	glClear(GL_COLOR_BUFFER_BIT);
		
	// Render the joypad if the accelerometer is not switched on
	if (!sharedGameController.eaglView.uiSwitch.on) {
		[joypad renderCenteredAtPoint:joypadCenter];
	}
	
	// Render the sprite of the knight
	[knight renderCenteredAtPoint:knightLocation];
	
	// Render images to screen
	[sharedImageRenderManager renderImages];
}

#pragma mark -
#pragma mark Touch events

- (void)touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event view:(UIView*)aView {
    
	for (UITouch *touch in touches) {
        // Get the point where the player has touched the screen
        CGPoint originalTouchLocation = [touch locationInView:aView];
        
        // As we have the game in landscape mode we need to switch the touches 
        // x and y coordinates
        CGPoint touchLocation = [sharedGameController adjustTouchOrientationForTouch:originalTouchLocation];
        
		if (CGRectContainsPoint(joypadBounds, touchLocation) && !isJoypadTouchMoving) {
			isJoypadTouchMoving = YES;
			joypadTouchHash = [touch hash];
			continue;
		}
		
		// Check if this touch is a double tap
		if (touch.tapCount == 2) {
			NSLog(@"Double Tap at X:%f Y:%f", touchLocation.x, touchLocation.y);
		}
	}
}


- (void)touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event view:(UIView*)aView {
	
    // Loop through all the touches
	for (UITouch *touch in touches) {
        
		if ([touch hash] == joypadTouchHash && isJoypadTouchMoving) {
			
			// Get the point where the player has touched the screen
			CGPoint originalTouchLocation = [touch locationInView:aView];
			
			// As we have the game in landscape mode we need to switch the touches 
			// x and y coordinates
			CGPoint touchLocation = [sharedGameController adjustTouchOrientationForTouch:originalTouchLocation];
			
			// Calculate the angle of the touch from the center of the joypad
			float dx = (float)joypadCenter.x - (float)touchLocation.x;
			float dy = (float)joypadCenter.y - (float)touchLocation.y;
			
			// Calculate the distance from the center of the joypad to the players touch.
			// Manhatten Distance
			joypadDistance = fabs(touchLocation.x - joypadCenter.x) + fabs(touchLocation.y - joypadCenter.y);
			
			// Calculate the new position of the knight based on the direction of the joypad and how far from the
			// center the joypad has been moved
			directionOfTravel = atan2(dy, dx);
		}
    }
}


- (void)touchesEnded:(NSSet*)touches withEvent:(UIEvent*)event view:(UIView*)aView {
    
	// Loop through the touches checking to see if the joypad touch has finished
	for (UITouch *touch in touches) {
		// If the hash for the joypad has reported that its ended, then set the
		// state as necessary
		if ([touch hash] == joypadTouchHash) {
			isJoypadTouchMoving = NO;
			joypadTouchHash = 0;
			directionOfTravel = 0;
			joypadDistance = 0;
			return;
		}
	}
}

#pragma mark -
#pragma mark Accelerometer

- (void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration {
    // This is a very basic low-pass filter
	accelerationValues[0] = acceleration.x * 0.1f + accelerationValues[0] * (1.0 - 0.1f);
	accelerationValues[1] = acceleration.y * 0.1f + accelerationValues[1] * (1.0 - 0.1f);
	accelerationValues[2] = acceleration.z * 0.1f + accelerationValues[2] * (1.0 - 0.1f);
}

@end
