//
//  TP02AppDelegate.m
//  TP02
//
//  Created by Abdelkader Gouaich on 8/22/11.
//  Copyright IUT, Université Montpellier 2 2011. All rights reserved.
//

#import "TP02AppDelegate.h"
#import "EAGLView.h"

@implementation TP02AppDelegate

@synthesize window;
@synthesize glView;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [glView startAnimation];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    [glView stopAnimation];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    [glView startAnimation];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    [glView stopAnimation];
}

- (void)dealloc
{
    [window release];
    [glView release];

    [super dealloc];
}

@end
