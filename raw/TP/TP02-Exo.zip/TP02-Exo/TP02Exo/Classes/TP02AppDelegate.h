//
//  TP02AppDelegate.h
//  TP02
//
//  Created by Abdelkader Gouaich on 8/22/11.
//  Copyright IUT, Université Montpellier 2 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EAGLView;

@interface TP02AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    EAGLView *glView;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet EAGLView *glView;

@end

