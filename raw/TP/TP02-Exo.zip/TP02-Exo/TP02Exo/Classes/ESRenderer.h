//
//  ESRenderer.h
//  TP02
//
//  Created by Abdelkader Gouaich on 8/22/11.
//  Copyright IUT, Université Montpellier 2 2011. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

#import <OpenGLES/EAGL.h>
#import <OpenGLES/EAGLDrawable.h>

@protocol ESRenderer <NSObject>

- (void)render;
- (BOOL)resizeFromLayer:(CAEAGLLayer *)layer;

@end
