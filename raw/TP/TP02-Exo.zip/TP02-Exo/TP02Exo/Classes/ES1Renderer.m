//
//  ES1Renderer.m
//  TP02
//  Created by Mike Daley on 29/08/2009. 
//  Adapted by Abdelkader Gouaich on 8/22/11.
//  Copyright IUT, Université Montpellier 2 2011. All rights reserved.
//
#import "Global.h"
#import "ES1Renderer.h"
#import "GameController.h"

#pragma mark -
#pragma mark interface privee

//[gouaich: creation d'une categorie Private pour mettre une methode privee
@interface ES1Renderer (Private)
// Initialize OpenGL
- (void)initOpenGL;
@end
//

#pragma mark -
#pragma mark implementation public

@implementation ES1Renderer

// Create an OpenGL ES 1.1 context
- (id)init
{
    if ((self = [super init]))
    {
        context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];

        if (!context || ![EAGLContext setCurrentContext:context])
        {
            [self release];
            return nil;
        }

        // Create default framebuffer object. The backing will be allocated for the current layer in -resizeFromLayer
        glGenFramebuffersOES(1, &defaultFramebuffer);
        glGenRenderbuffersOES(1, &colorRenderbuffer);
        glBindFramebufferOES(GL_FRAMEBUFFER_OES, defaultFramebuffer);
        glBindRenderbufferOES(GL_RENDERBUFFER_OES, colorRenderbuffer);
        glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER_OES, colorRenderbuffer);
		
		//[gouaich
		sharedGameController = [GameController sharedGameController];
		//]
    }

    return self;
}


/*[ gouaich
On remplace le code existant avec une methode plus generique. On va
 faire le rendu de la scene courante.
]*/
- (void) render {
	//effacer le buffer couleurs et l ecran
	glClear(GL_COLOR_BUFFER_BIT);
	//demande de faire le rendu de la scene courante
	[sharedGameController renderCurrentScene];
	//presente le buffer rendu a l ecran
	[context presentRenderbuffer:GL_RENDERBUFFER_OES];
}

- (BOOL)resizeFromLayer:(CAEAGLLayer *)layer
{	
    // Allocate color buffer backing based on the current layer size
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, colorRenderbuffer);
    [context renderbufferStorage:GL_RENDERBUFFER_OES fromDrawable:layer];
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES, &backingWidth);
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &backingHeight);

    if (glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) != GL_FRAMEBUFFER_COMPLETE_OES)
    {
        NSLog(@"Failed to make complete framebuffer object %x", glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES));
        return NO;
    }

	//[gouaich: initialisation de openGL
	[self initOpenGL];
	//]
    return YES;
}

- (void)dealloc
{
    // Tear down GL
    if (defaultFramebuffer)
    {
        glDeleteFramebuffersOES(1, &defaultFramebuffer);
        defaultFramebuffer = 0;
    }

    if (colorRenderbuffer)
    {
        glDeleteRenderbuffersOES(1, &colorRenderbuffer);
        colorRenderbuffer = 0;
    }

    // Tear down context
    if ([EAGLContext currentContext] == context)
        [EAGLContext setCurrentContext:nil];

    [context release];
    context = nil;

    [super dealloc];
}

@end

#pragma mark -
#pragma mark implementation privee
//gouaich: implementation des methodes de la categorie Private
@implementation ES1Renderer (Private)

- (void)initOpenGL
{
	LOG(@"ES1Renderer initOpenGL");
	
	// Passer dans le mode projection  GL_PROJECTION et reset de la matrice avec l'identite
	glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    
	//mise en place d'une projection direct (sans perspective)
	glOrthof(0, backingWidth, 0, backingHeight, -1, 1);
	//configuration de la fenetre de rendu
	glViewport(0, 0, backingWidth , backingHeight);
	
	//Passer dans le mode GL_MODELVIEW et mettre comme matrice l'identite
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//Metter en place une couleur pour effacer l'ecran
	glClearColor(0.0f,0.0f,0.0f,1.0f);
	//desactive le test des profondeur pour gagner des perfs. Nous sommes en 2D.
	glDisable(GL_DEPTH_TEST);
	
	//utilisation d'un tableau de Vertex
	glEnableClientState(GL_VERTEX_ARRAY);
	//utilisation d'un tableau de couleurs
	glEnableClientState(GL_COLOR_ARRAY);
	
	
	
	

}
@end
