/*
 * Log macro
 */

#import <OpenGLES/ES1/gl.h>

#define LOG(...) NSLog(__VA_ARGS__);
//#define LOG(...)
