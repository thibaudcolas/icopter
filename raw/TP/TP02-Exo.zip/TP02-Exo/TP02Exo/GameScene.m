//
//  GameScene.m
//  SLQTSOR
//
//  Created by Mike Daley on 29/08/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//  Modified by A. Gouaich.

#import "GameScene.h"


@implementation GameScene

- (void)updateSceneWithDelta:(float)aDelta {
		//demande d'une translation d'un objet
		//TODO
	
}

// pour ce TP nous allons simplement dessiner un carre
- (void)renderScene {

	// { {x,y} ...}
    static const GLfloat squareVertices[] = {
        50,  50, // 1
		250,  50,// 2
        50,   250, // 3
		250,   250, // 4

    };
	
	
    static const GLubyte squareColors[] = {
        255, 0,   0, 255,
        255, 0, 0, 255,
        255, 255,   0,   0,
        255, 0, 0, 255,
    };
    
	//translation de l'objet avec la fonction glTranslate(x,y,z)
	
	
	//TODO
	
	
	
	//declaration d'un pointeur vers des Vertex
    glVertexPointer(2, GL_FLOAT, 0, squareVertices);
	//
    glColorPointer(4, GL_UNSIGNED_BYTE, 0, squareColors);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	
}


@end
