//
//  GameScene.h
//  
//
//  Created by Mike Daley on 29/08/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//

#import "AbstractScene.h"
#import "Global.h"


@interface GameScene : AbstractScene {
	float transY;
}

@end
