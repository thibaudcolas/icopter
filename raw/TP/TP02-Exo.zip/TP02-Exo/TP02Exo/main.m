//
//  main.m
//  TP02
//
//  Created by Abdelkader Gouaich on 8/22/11.
//  Copyright IUT, Université Montpellier 2 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
