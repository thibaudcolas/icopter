//
//  Pumpkin.h
//  SLQTSOR
//
//  Created by Mike Daley on 28/10/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//

#import "AbstractEntity.h"

@interface Pumpkin : AbstractEntity {


}

@end
