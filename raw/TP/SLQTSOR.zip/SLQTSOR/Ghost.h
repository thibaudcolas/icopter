//
//  Monk.h
//  Tutorial1
//
//  Created by Michael Daley on 22/06/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//

#import "AbstractEntity.h"

@interface Ghost : AbstractEntity {

}

@end
