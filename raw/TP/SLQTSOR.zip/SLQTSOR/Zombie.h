//
//  Zombie.h
//  SLQTSOR
//
//  Created by Mike Daley on 07/11/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//
#import "AbstractEntity.h"

@interface Zombie : AbstractEntity {

}

@end
