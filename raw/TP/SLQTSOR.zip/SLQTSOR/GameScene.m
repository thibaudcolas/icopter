//
//  GameScene.m
//  SLQTSOR
//
//  Created by Michael Daley on 31/05/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "Global.h"
#import "GameController.h"
#import "ImageRenderManager.h"
#import "GameScene.h"
#import "TextureManager.h"
#import "SoundManager.h"
#import "AbstractEntity.h"
#import "Image.h"
#import "SpriteSheet.h"
#import "Animation.h"
#import "TiledMap.h"
#import "BitmapFont.h"
#import "ParticleEmitter.h"
#import "Player.h"
#import "Door.h"
#import "Ghost.h"
#import "Pumpkin.h"
#import "Bat.h"
#import "Vampire.h"
#import "Zombie.h"
#import "Witch.h"
#import "Frank.h"
#import "Axe.h"
#import "Portal.h"
#import "Primitives.h"
#import "PackedSpriteSheet.h"
#import "Layer.h"
#import "EnergyObject.h"
#import "KeyObject.h"
#import "MapObject.h"
#import "ParchmentObject.h"
#import "Primitives.h"

#pragma mark -
#pragma mark Private interface

@interface GameScene (Private)
// Initialize the sound needed for this scene
- (void)initSound;

// Initialize/reset the game
- (void)initScene;

// Sets up the game from the previously saved game.  If any of the data files are
// missing then the resume will not take place and the initial game state will be
// used instead
- (void)loadGameState;

// Initializes the games state
- (void)initNewGameState;

// Checks the game controller for the joypadPosition value. This is used to decide where the 
// joypad should be rendered i.e. for left or right handed players.
- (void)checkJoypadSettings;

// Initialize the game content e.g. tile map, collision array
- (void)initGameContent;

// Initializes portals defined in the tile map
- (void)initPortals;

// Initializes items defined in the tile map
- (void)initItems;

// Initiaize the doors used in the map
- (void)initCollisionMapAndDoors;

// Initializes the tile map
- (void)initTileMap;

// Initializes the localDoor array before the update loop starts.  This means that doors will be
// rendered correctly when the scene fades in
- (void)initLocalDoors;

// Calculate the players tile map location.  This inforamtion is used when rendering the tile map
// layers in the render method
- (void)calculatePlayersTileMapLocation;

// Deallocates resources this scene has created
- (void)deallocResources;

@end

#pragma mark -
#pragma mark Public implementation

@implementation GameScene

@synthesize castleTileMap;
@synthesize player;
@synthesize gameEntities;
@synthesize gameObjects;
@synthesize axe;
@synthesize doors;
@synthesize gameStartTime;
@synthesize timeSinceGameStarted;
@synthesize score;
@synthesize gameTimeToDisplay;
@synthesize locationName;

- (void)dealloc {
    
    // Remove observers that have been set up
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"hidingSettings" object:nil];

	// Dealloc resources this scene has created
	[self deallocResources];
	
    [super dealloc];
}

- (id)init {
    
    if(self = [super init]) {
        
		// Name of this scene
        self.name = @"game";
		
        // Grab an instance of our singleton classes
        sharedImageRenderManager = [ImageRenderManager sharedImageRenderManager];
        sharedTextureManager = [TextureManager sharedTextureManager];
        sharedSoundManager = [SoundManager sharedSoundManager];
        sharedGameController = [GameController sharedGameController];
        
        // Grab the bounds of the screen
        screenBounds = [[UIScreen mainScreen] bounds];

        // Set the scenes fade speed which is used when fading the scene in and out and also set
        // the default alpha value for the scene
        fadeSpeed = 1.0f;
        alpha = 0.0f;
		musicVolume = 0.0f;
		
		// Add observations on notifications we are interested in.  When the settings view is hidden we
		// want to check to see if the joypad settings have changed.  For this reason we look for this
		// notification
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkJoypadSettings) name:@"hidingSettings" object:nil];
    }
    
    return self;
}

#pragma mark -
#pragma mark Update scene logic

- (void)updateSceneWithDelta:(GLfloat)aDelta {
    
	// Clear the screen before rendering
	glClear(GL_COLOR_BUFFER_BIT);

	switch (state) {
            
        #pragma mark kSceneState_Running
        case kSceneState_Running:
            
            // Update the game timer if the player is alive
            if (player.state == kEntityState_Alive || player.state == kEntityState_Appearing)
                timeSinceGameStarted += aDelta;

			// Calculate the minutes and seconds that have passed since the game started
            gameSeconds = (int)timeSinceGameStarted % 60;
            gameMinutes = (int)timeSinceGameStarted / 60;
			
            // Release the gameTime string before we create it and retain it.  We retain it to make sure 
            // that it is available even if this code is not run i.e. the game is paused.  The release
            // makes sure we release it and don't leak memory.
            NSString *timeSeconds = [NSString stringWithFormat:@"%02d", gameSeconds];
            NSString *timeMinutes = [NSString stringWithFormat:@"%03d", gameMinutes];
            self.gameTimeToDisplay = [NSString stringWithFormat:@"%@.%@", timeMinutes, timeSeconds] ;
            
            // Update player
            [player updateWithDelta:aDelta scene:self];

			// Set the size of the healthbar to be rendered based on the players energy
			[healthBar setImageSizeToRender:CGSizeMake(player.energy, 75)];

            // Now we have updated the player we need to update their position relative to the tile map
            [self calculatePlayersTileMapLocation];

            // Update the players sword if its state is alive
			if (axe.state == kEntityState_Alive)
				[axe updateWithDelta:aDelta scene:self];

			// Calculate the tile bounds around the player. We clamp the possbile values to between
			// 0 and the width/height of the tile map.  We remove 1 from the width and height
			// as the tile map is zero indexed in the game.  These values can then be used when
			// checking if objects, portals or doors should be updated
			int minScreenTile_x = CLAMP(player.tileLocation.x - 8, 0, kMax_Map_Width-1);
			int maxScreenTile_x = CLAMP(player.tileLocation.x + 8, 0, kMax_Map_Width-1);
			int minScreenTile_y = CLAMP(player.tileLocation.y - 6, 0, kMax_Map_Height-1);
			int maxScreenTile_y = CLAMP(player.tileLocation.y + 6, 0, kMax_Map_Height-1);
			
			// Update the game objects that are inside the bounds calculated above
			isPlayerOverObject = NO;
            for(AbstractObject *gameObject in gameObjects) {
                
                if (gameObject.tileLocation.x >= minScreenTile_x && gameObject.tileLocation.x <= maxScreenTile_x &&
                    gameObject.tileLocation.y >= minScreenTile_y && gameObject.tileLocation.y <= maxScreenTile_y) {

                    // Update the object
                    [gameObject updateWithDelta:aDelta scene:self];

                    if (gameObject.state == kObjectState_Active) {
						[player checkForCollisionWithObject:gameObject];
						[gameObject checkForCollisionWithEntity:player];
						if (gameObject.isCollectable) {
							isPlayerOverObject = YES;
						}
                    }
                }
            }
            
            // Update entities, check if they have collided with anything and spawn new ones.  There are so few entities that updating 
			// them all is not a performance issue and so no checks are performed to limit the number of entities that need to be
			// updated.
            for(AbstractEntity *entity in gameEntities) {

				// Update the current entity
				[entity updateWithDelta:aDelta scene:self];
		
				switch (entity.state) {
					
					case kEntityState_Alive:
						// Get the player to see if it has hit the entity and also ask the entity to see if it has
						// hit the player.  Each entity has its own way of resolving a collision so both checks are
						// necessary.
						[player checkForCollisionWithEntity:entity];
						[entity checkForCollisionWithEntity:player];
						
						// Check to see if the axe has collided with the current entity
						if(axe.state == kEntityState_Alive) {
							[entity checkForCollisionWithEntity:axe];
						}
						break;
						
					// If the entity is dead then we can revive it somewhere new near the player
					case kEntityState_Dead:
					{
						// We check to see what type of entity we have found and then check how long the player
						// has been playing the game.  Only certain baddies are brought to life based on how
						// long the game has been running.  Basially slowly introducing baddies as the player plays
						BOOL resurectBaddie = NO;
						
						if ([entity isKindOfClass:[Ghost class]] && timeSinceGameStarted >= 15) {
							resurectBaddie = YES;
						} else if ([entity isKindOfClass:[Pumpkin class]] && timeSinceGameStarted >= 60) {
							resurectBaddie = YES;
						} else if ([entity isKindOfClass:[Bat class]] && timeSinceGameStarted >= 120) {
							resurectBaddie = YES;
						} else if ([entity isKindOfClass:[Zombie class]] && timeSinceGameStarted >= 150) {
							resurectBaddie = YES;
						} else if ([entity isKindOfClass:[Witch class]] && timeSinceGameStarted >= 240) {
							resurectBaddie = YES;
						} else if ([entity isKindOfClass:[Vampire class]] && timeSinceGameStarted >= 180) {
							resurectBaddie = YES;
						} else if ([entity isKindOfClass:[Frank class]] && timeSinceGameStarted >= 300) {
							resurectBaddie = YES;
						}
						
						if (resurectBaddie) {
							// Calculate a random position
							float entityx = player.tileLocation.x + ((20 * RANDOM_0_TO_1()) * RANDOM_MINUS_1_TO_1());
							float entityy = player.tileLocation.y + ((20 * RANDOM_0_TO_1()) * RANDOM_MINUS_1_TO_1());
							
							// Set the entities position as calculated above
							CGPoint entityLocation = CGPointMake(entityx, entityy);
							[entity setTileLocation:entityLocation];
							
							// Check each corner of the entities bounding box to make sure they would not spawn in a blocked tile.
							CGRect bRect = [entity movementBounds];
							BoundingBoxTileQuad bbtq = getTileCoordsForBoundingRect(bRect, CGSizeMake(kTile_Width, kTile_Height));
							
							if(![self isBlocked:bbtq.x1 y:bbtq.y1] && 
							   ![self isBlocked:bbtq.x2 y:bbtq.y2] &&
							   ![self isBlocked:bbtq.x3 y:bbtq.y3] && 
							   ![self isBlocked:bbtq.x4 y:bbtq.y4] &&
							   (int)player.tileLocation.x != (int)entity.tileLocation.x &&
							   (int)player.tileLocation.y != (int)entity.tileLocation.y)

								// The spawn point is ok so set the entities state to appearing which will cause
								// it to appear in the new location
								entity.state = kEntityState_Appearing;
						}

						break;
					}
					default:
						break;
				}
			}

			// Update portals that are within the visible screen
            for(AbstractEntity *portal in portals) {
				if (portal.tileLocation.x >= minScreenTile_x && portal.tileLocation.x <= maxScreenTile_x &&
                    portal.tileLocation.y >= minScreenTile_y && portal.tileLocation.y <= maxScreenTile_y) {
					[portal updateWithDelta:aDelta scene:self];
					[portal checkForCollisionWithEntity:player];
				}
			}
			
            // Populate the localDoors array with any doors that are found around the player.  This allows
            // us to reduce the number of doors we are rendering and updating in any single frame.  We only
			// perform this check if the player has moved from one tile to another on the tile map to save cycles
            if ((int)player.tileLocation.x != (int)playersLastLocation.x || (int)player.tileLocation.y != (int)playersLastLocation.y) {
                
				// Clear the localDoors array as we are about to populate it again based on the 
                // players new position
                [localDoors removeAllObjects];
                
                // Find doors that are close to the player and add them to the localDoors loop.  Layer 3 in the 
				// tile map holds the door information. Updating all doors in the map is a real performance hog
				// so only updating those near the player is necessary
                Layer *layer = [[castleTileMap layers] objectAtIndex:2];
                for (int yy=minScreenTile_y; yy < maxScreenTile_y; yy++) {
                    for (int xx=minScreenTile_x; xx < maxScreenTile_x; xx++) {
						
                        // If the value property for this tile is not -1 then this must be a door and
                        // we should add it to the localDoors array
                        if ([layer valueAtTile:CGPointMake(xx, yy)] > -1) {
                            int index = [layer valueAtTile:CGPointMake(xx, yy)];
                            [localDoors addObject:[NSNumber numberWithInt:index]];
                        }
                    }
                }
            }
			
			// Update all doors in the localDoors array populated above
            for (int index=0; index < [localDoors count]; index++) {
                Door *door = [doors objectAtIndex:[[localDoors objectAtIndex:index] intValue]];
                [door updateWithDelta:aDelta scene:self];
            }

			// Check to see if the player has all the parchment.  If so then unlock the front door.  If then block
			// the front door
			if (player.hasParchmentTop && player.hasParchmentMiddle && player.hasParchmentBottom) {
				// Unblock the two tiles where the front door is.  This will allow the player to move through the door
				// and we will then pick up a collision with a rectangle that lets us know they have moved through the
				// door
				blocked[99][2] = NO;
				blocked[100][2] = NO;
				blocked[99][1] = NO;
				blocked[100][1] = NO;
				blocked[99][0] = NO;
				blocked[100][0] = NO;
				isMainDoorOpen = YES;
			} else {
				// The player may drop a parchment piece when they are stood in the door way.  If they do that then we don't
				// block the door while they are stood in it or they will get stuck
				if (![player isEntityInTileAtCoords:CGPointMake(99, 2)] && ![player isEntityInTileAtCoords:CGPointMake(100, 2)]) {
					blocked[99][2] = YES;
					blocked[100][2] = YES;
					blocked[99][1] = YES;
					blocked[100][1] = YES;
					blocked[99][0] = YES;
					blocked[100][0] = YES;
					isMainDoorOpen = NO;
				}
			}
			
			// Check to see if the player has collided with the exit rectangle.  If so then the game is over and they
			// can go home for a nice cup of tea!!
			if (CGRectIntersectsRect([player movementBounds], exitBounds)) {
				state = kSceneState_GameCompleted;
			}
			
			// Record the players current position previous position so we can check if the player has
			// moved between updates
            playersLastLocation = player.tileLocation;
            
            break;

        #pragma mark kSceneState_TransportingOut
        case kSceneState_TransportingOut:
            alpha += fadeSpeed * aDelta;
            fadeImage.color = Color4fMake(1, 1, 1, alpha);

            if(alpha >= 1.0f) {
                alpha = 1.0f;
                state = kSceneState_TransportingIn;

				// Now we have faded out the scene, set the players new position i.e. the beam location
				// and make the scene transition in
				player.tileLocation = player.beamLocation;
				player.pixelLocation = tileMapPositionToPixelPosition(player.tileLocation);
				
				// Now we have loaded the player we need to set up their position in the tilemap
				[self calculatePlayersTileMapLocation];
				
				// Init the doors local to the players new position
				[self initLocalDoors];
            }
            break;

        #pragma mark kSceneState_TransportingIn
        case kSceneState_TransportingIn:
            alpha -= fadeSpeed * aDelta;
            fadeImage.color = Color4fMake(1, 1, 1, alpha);

			// Once the scene has faded in, start the scene running and
			// also reset the joypad settings.  This removes any issues with
			// the state of the joypad before the transportation takes place
            if(alpha <= 0.0f) {
                alpha = 0.0f;
                state = kSceneState_Running;
				isJoypadTouchMoving = NO;
				joypadTouchHash = 0;
				player.angleOfMovement = 0;
				player.speedOfMovement = 0;
            }
            break;
		
		#pragma mark kSceneState_Loading
		case kSceneState_Loading:
			// If there is a game to resume and the game has not been initialized
            // then use the saved game state to init the game else use the default
            // game state
            if (!isGameInitialized) {
				isGameInitialized = YES;
				
				// Set the alpha to be used when fading
				alpha = 1.0f;
				
                if(sharedGameController.shouldResumeGame) {
                    [self loadGameState];
                } else {
					[self initNewGameState];
                }
				
				// Setup the joypad based on the current settings
				[self checkJoypadSettings];
            }
            
            // Update the alpha for this scene using the scenes fadeSpeed.  We are not actually
			// fading all the elements on the screen.  Instead we are changing the alpha value
			// of a fully black image that is drawn over the entire scene and faded out.  This
			// gives us a nice consistent fade across all objects, including those rendered ontop
			// of other graphics such as objects on the tilemap
            alpha -= fadeSpeed * aDelta;
            fadeImage.color = Color4fMake(1, 1, 1, alpha);
			
            // Once the scene has faded in start playing the background music and set the
			// scene to running
			if(alpha < 0.0f) {
				alpha = 0.0f;
				fadeImage.color = Color4fMake(1, 1, 1, alpha);
				isLoadingScreenVisible = NO;
                state = kSceneState_Running;
				
				// Now the game is running we check to see if it was a resumed game.  If not then we play the spooky
				// voice otherwise we just play the music
				if(sharedGameController.shouldResumeGame) {
					if (!sharedSoundManager.isMusicPlaying && !sharedSoundManager.isExternalAudioPlaying) {
						sharedSoundManager.currentMusicVolume = 0;	// Make sure the music volume is down before playing the music
						[sharedSoundManager playMusicWithKey:@"ingame" timesToRepeat:-1];
						[sharedSoundManager fadeMusicVolumeFrom:0 toVolume:sharedSoundManager.musicVolume duration:0.8f stop:NO];
					}
				} else {
					if (!sharedSoundManager.isMusicPlaying && !sharedSoundManager.isExternalAudioPlaying) {
						sharedSoundManager.loopLastPlaylistTrack = YES;
						sharedSoundManager.currentMusicVolume = sharedSoundManager.musicVolume;
						[sharedSoundManager startPlaylistNamed:@"inGame"];
					}
				}
            }
			break;
			
        #pragma mark kSceneState_TransitionIn
        case kSceneState_TransitionIn:
			if (!isSceneInitialized) {
				isSceneInitialized = YES;
				[self initScene];
				[self initSound];
			}
			
			if (isLoadingScreenVisible) {
				state = kSceneState_Loading;
			}
            break;
			
		#pragma mark kSceneState_TransitionOut
        case kSceneState_TransitionOut:

			if (!isMusicFading) {
				isMusicFading = YES;
				[sharedSoundManager fadeMusicVolumeFrom:sharedSoundManager.musicVolume toVolume:0 duration:0.8f stop:YES];
				alpha = 0;
			}
			
			alpha += fadeSpeed * aDelta;
			fadeImage.color = Color4fMake(1, 1, 1, alpha);
			
            if(alpha > 1.0f) {
                alpha = 1.0f;
                state = kSceneState_Idle;
				
				// Deallocate the resources this scene has created
				[self deallocResources];
				
				// Reset game flags
				isGameInitialized = NO;
				timeSinceGameStarted = 0;
				score = 0;
				isJoypadTouchMoving = NO;
				isSceneInitialized = NO;
				isLoadingScreenVisible = NO;
				isMusicFading = NO;
				
				// Transition to the menu scene
				[sharedGameController transitionToSceneWithKey:@"menu"];
            }
            break;

		#pragma mark ksceneState_GameOver
		case kSceneState_GameOver:
			if (!isLoseMusicPlaying && !sharedSoundManager.isExternalAudioPlaying) {
				isLoseMusicPlaying = YES;
				sharedSoundManager.usePlaylist = YES;
				sharedSoundManager.loopLastPlaylistTrack = YES;
				[sharedSoundManager startPlaylistNamed:@"lose"];

				// Delete the old gamestate file
				[sharedGameController deleteGameState];

			}
			break;

		#pragma mark kSceneState_GameCompleted
		case kSceneState_GameCompleted:
			if (!isWinMusicPlaying && !sharedSoundManager.isExternalAudioPlaying) {
				isWinMusicPlaying = YES;
				sharedSoundManager.usePlaylist = YES;
				sharedSoundManager.loopLastPlaylistTrack = YES;
				[sharedSoundManager startPlaylistNamed:@"win"];
				
				// Delete the old gamestate file
				[sharedGameController deleteGameState];

			}
			break;
        default:
            break;
    }
}

#pragma mark -
#pragma mark Tile map functions

- (BOOL)isBlocked:(float)x y:(float)y {
	// If we are asked for blocking information that is beyond the map border then by default
	// return yes.  When the player is moving near the edge of the map coordinates may be passed
	// that are beyond these bounds
	if (x < 0 || y < 0 || x > kMax_Map_Width || y > kMax_Map_Height) {
		return YES;
	}
	
	// Return the blocked status of the specified tile
    return blocked[(int)x][(int)y];
}

- (void)setBlocked:(float)aX y:(float)aY blocked:(BOOL)aState {
    blocked[(int)aX][(int)aY] = aState;
}

- (BOOL)isEntityInTileAtCoords:(CGPoint)aPoint {
    // By default nothing is at the point provided
    BOOL result = NO;

    // Check to see if any of the entities are in the tile provided
    for(AbstractEntity *entity in gameEntities) {
        if([entity isEntityInTileAtCoords:aPoint]) {
            result = YES;
            break;
        }
    }
    
    // Also check to see if the sword is in the tile provided
    if([axe isEntityInTileAtCoords:aPoint])
        result = YES;
    
    return result;
}

#pragma mark -
#pragma mark Touch events

- (void)touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event view:(UIView*)aView {
    
    for (UITouch *touch in touches) {
        // Get the point where the player has touched the screen
        CGPoint originalTouchLocation = [touch locationInView:nil];
        
        // As we have the game in landscape mode we need to switch the touches 
        // x and y coordinates
        CGPoint touchLocation = [sharedGameController adjustTouchOrientationForTouch:originalTouchLocation];
        
		switch (state) {
			case kSceneState_Running:
				if (CGRectContainsPoint(joypadBounds, touchLocation) && !isJoypadTouchMoving) {
					isJoypadTouchMoving = YES;
					joypadTouchHash = [touch hash];
					break;
				}
				
				// Check to see if the pickup button was pressed
				if (CGRectContainsPoint(pickupButtonBounds, touchLocation)) {
					
					// Loop through the game objects and if an object is found to be collectable
					// then add it to the players inventory
					for(AbstractObject *gameObject in gameObjects) {
						if (gameObject.isCollectable || gameObject.state == kObjectState_Inventory) {
							[player placeInInventoryObject:gameObject];
						}
					}
					break;
				}
				
				// Check to see if one of the inventory slots was selected
				if (CGRectContainsPoint(invItem1Bounds, touchLocation)) {
					[player dropInventoryFromSlot:0];
					break;
				}
				if (CGRectContainsPoint(invItem2Bounds, touchLocation)) {
					[player dropInventoryFromSlot:1];
					break;
				}
				if (CGRectContainsPoint(invItem3Bounds, touchLocation)) {
					[player dropInventoryFromSlot:2];
					break;
				}
				
				// Check to see if the settings button has been pressed
				if (CGRectContainsPoint(settingsBounds, touchLocation)) {
					[[NSNotificationCenter defaultCenter] postNotificationName:@"showSettings" object:self];
					break;
				}

				// Next check to see if the pause/play button has been pressed
				if (CGRectContainsPoint(pauseButtonBounds, touchLocation)) {
					[sharedSoundManager pauseMusic];
					state = kSceneState_Paused;
					
					// If the joypad was being tracked then reset it
					isJoypadTouchMoving = NO;
					joypadTouchHash = 0;
					player.angleOfMovement = 0;
					player.speedOfMovement = 0;
					break;
				}
				
				// As the player has tapped the screen then fire the axe.
				if(axe.state == kEntityState_Idle && player.state == kEntityState_Alive) {
					// Set the axe state to alive
					axe.state = kEntityState_Alive;
					
					// Set the axe to the same location as the plaeyr
					axe.tileLocation = player.tileLocation;
					
					// If the fireDirection in the settings is set to player, then set the axe angle
					// to the angle the player is moving.
					if (sharedGameController.fireDirection == 0) {
						axe.throwAngle = joyPadAngle;
					} else {
						// If the fire direction is set to touch, then the axe is thrown towards the
						// touch in relation to the player
						float dx = (float)240 - (float)touchLocation.x;
						float dy = (float)160 - (float)touchLocation.y;
						axe.throwAngle = atan2(dy, dx);
					}
				}
				break;
				
			case kSceneState_GameCompleted:
			case kSceneState_GameOver:
			{
				// The game is over and we want to get the players name for the score board.  We are going to a UIAlertview
				// to do this for us.  The message which is defined as "anything" cannot be blank else the buttons on the 
				// alertview will overlap the textfield.
				UIAlertView *playersNameAlertView = [[UIAlertView alloc] initWithTitle:@"Enter Your Name" message:@"anything" 
																			  delegate:self cancelButtonTitle:@"Dismiss" 
																	 otherButtonTitles:@"OK", nil];

				// Before iOS 4, it was necessary to move the alert view up manually, so that the keyboard did not cover the
				// alert. With iOS 4, this has been changed and the alert view is moved automatically. The following check
				// is done to only move the alert box if the game is running on an earlier version of iOS.
				NSString *reqSysVer = @"4.0";
				NSString *currSysVer = [[UIDevice currentDevice] systemVersion];
				if ([currSysVer compare:reqSysVer options:NSNumericSearch] == NSOrderedAscending)
				{
					CGAffineTransform transform = CGAffineTransformMakeTranslation(0, 80);
					playersNameAlertView.transform = transform;
				}
				
				// Now we have moved the view we need to create a UITextfield to add to the view
				UITextField *playersNameTextField = [[UITextField alloc] initWithFrame:CGRectMake(12, 35, 260, 20)];

				// We set the background to white and the tag to 99.  This allows us to reference the text field in the alert
				// view later on to get the text that is typed in.  We also set it to becomeFirstResponder so that the keyboard
				// automatically shows
				playersNameTextField.backgroundColor = [UIColor whiteColor];
				playersNameTextField.tag = 99;
				[playersNameTextField becomeFirstResponder];
				
				// Add the textfield to the alert view
				[playersNameAlertView addSubview:playersNameTextField];

				// Show the alert view and then release it and the textfield.  As they are shown a retain is held.  If
				// we do not release then we will leak memory when the view is dismissed.
				[playersNameAlertView show];
				[playersNameAlertView release];
				[playersNameTextField release];
				break;
			}
				
			case kSceneState_Paused:
				// Check to see if the pause/play button has been pressed
				if (CGRectContainsPoint(pauseButtonBounds, touchLocation)) {
					[sharedSoundManager resumeMusic];
					state = kSceneState_Running;
				}
				break;
			
			default:
				break;
		}
    }
}


- (void)touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event view:(UIView*)aView {

    // Loop through all the touches
	for (UITouch *touch in touches) {
        
		// If the scene is running then check to see if we have a running joypad touch
        if (state == kSceneState_Running) {
            if ([touch hash] == joypadTouchHash && isJoypadTouchMoving) {
                
				// Get the point where the player has touched the screen
                CGPoint originalTouchLocation = [touch locationInView:nil];
                
                // As we have the game in landscape mode we need to switch the touches 
                // x and y coordinates
				CGPoint touchLocation = [sharedGameController adjustTouchOrientationForTouch:originalTouchLocation];
					                
                // Calculate the angle of the touch from the center of the joypad
                float dx = (float)joypadCenter.x - (float)touchLocation.x;
                float dy = (float)joypadCenter.y - (float)touchLocation.y;

				// Calculate the distance from the center of the joypad to the players touch using the manhatten
				// distance algorithm
				float distance = fabs(touchLocation.x - joypadCenter.x) + fabs(touchLocation.y - joypadCenter.y);
				
                // Set the players joypadAngle causing the player to move in that direction
				joyPadAngle = atan2(dy, dx);
                [player setDirectionWithAngle:joyPadAngle speed:CLAMP(distance/4, 0, 8)];
            }
        }
    }
}


- (void)touchesEnded:(NSSet*)touches withEvent:(UIEvent*)event view:(UIView*)aView {
    
    switch (state) {
        case kSceneState_Running:
            // Loop through the touches checking to see if the joypad touch has finished
            for (UITouch *touch in touches) {
                // If the hash for the joypad has reported that its ended, then set the
                // state as necessary
                if ([touch hash] == joypadTouchHash) {
                    isJoypadTouchMoving = NO;
                    joypadTouchHash = 0;
                    player.angleOfMovement = 0;
					player.speedOfMovement = 0;
                    return;
                }
            }
            break;

        default:
            break;
    }
}

#pragma mark -
#pragma mark Alert View Delegates

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {

	// First off grab a refernce to the textfield on the alert view.  This is done by hunting
	// for tag 99
	UITextField *nameField = (UITextField *)[alertView viewWithTag:99];

	// If the OK button is pressed then set the playersname
	if (buttonIndex == 1) {
		playersName = nameField.text;
		if ([playersName length] == 0)
			playersName = @"No Name Given";

		// Save the games info to the high scores table only if a players name has been entered
		if (playersName) {
			BOOL won = NO;
			if (state == kSceneState_GameCompleted)
				won = YES;
			[sharedGameController addToHighScores:score gameTime:gameTimeToDisplay playersName:playersName didWin:won];
		}
	}
	
	// We must remember to resign the textfield before this method finishes.  If we don't then an error
	// is reported e.g. "wait_fences: failed to receive reply:"
	[nameField resignFirstResponder];

	// Finally set the state to transition out of the scene
	state = kSceneState_TransitionOut;
}

#pragma mark -
#pragma mark Transition

- (void)transitionToSceneWithKey:(NSString*)theKey {
    state = kSceneState_TransitionOut;
}

- (void)transitionIn {
    state = kSceneState_TransitionIn;
}

#pragma mark -
#pragma mark Render scene

- (void)renderScene {

	// If we are transitioning into the scene and we have initialized the scene then display the loading
	// screen.  This will be displayed until the rest of the game content has been loaded.
	if (state == kSceneState_TransitionIn && isSceneInitialized) {
		largeFont.fontColor = Color4fMake(1, 1, 1, 1);
		[largeFont renderStringJustifiedInFrame:CGRectMake(0, 0, 480, 320) justification:BitmapFontJustification_MiddleCentered text:@"Entering Egremont Castle..."];
		[sharedImageRenderManager renderImages];
		isLoadingScreenVisible = YES;
	}
	
	// Only render if the game has been initialized
	if (isGameInitialized) {
		switch (state) {
				
			case kSceneState_Loading:
			case kSceneState_TransitionOut:
			case kSceneState_TransportingOut:
			case kSceneState_TransportingIn:
			case kSceneState_Paused:
			case kSceneState_Running:
			{
				// Clear the screen before rendering
				glClear(GL_COLOR_BUFFER_BIT);
			
				// Save the current Matrix
				glPushMatrix();
				
				// Translate the world coordinates so that the player is rendered in the middle of the screen
				glTranslatef(240 - player.pixelLocation.x, 160 - player.pixelLocation.y, 0);
				
				// Render the Map tilemap layer
				[castleTileMap renderLayer:0
									  mapx:playerTileX - leftOffsetInTiles - 1 
									  mapy:playerTileY - bottomOffsetInTiles - 1 
									 width:screenTilesWide + 2 
									height:screenTilesHeight + 2 
							   useBlending:NO];
				
				// Render the Objects tilemap layer
				[castleTileMap renderLayer:1 
									  mapx:playerTileX - leftOffsetInTiles - 1 
									  mapy:playerTileY - bottomOffsetInTiles - 1 
									 width:screenTilesWide + 2 
									height:screenTilesHeight + 2 
							   useBlending:YES];

				[sharedImageRenderManager renderImages];
				
				// Render the players sword if its state is alive
				if(axe.state == kEntityState_Alive)
					[axe render];
				
				// Render the game objects
				for(AbstractObject *gameObject in gameObjects) {
					if (gameObject.state == kObjectState_Active) {
						[gameObject render];
					}
				}
				
				// Render the player
				[player render];
				
				// Render entities
				for(AbstractEntity *entity in gameEntities) {
					[entity render];
				}

				// Render what we have so far so that everything else rendered is drawn over it
				[sharedImageRenderManager renderImages];
				
				// Render the doors onto the map.  The localDoors array holds all doors
				// that have been found to be close to the player during the scenes update
				for (int index=0; index < [localDoors count]; index++) {
					Door *door = [doors objectAtIndex:[[localDoors objectAtIndex:index] intValue]];
					[door render];
				}
				
				// Render the portals
				for(AbstractEntity *portal in portals) {
					[portal render];
				}
				
				// Render the main door
				if (isMainDoorOpen) {
					[openMainDoor renderAtPoint:CGPointMake(3960, 80)];
				} else {
					[closedMainDoor renderAtPoint:CGPointMake(3960, 80)];
				}

				// Render all queued images at this point
				[sharedImageRenderManager renderImages];
				
				// Pop the old matrix off the stack ready for the next frame.  We need to make sure that the modelview
				// is using the origin 0, 0 again so that the images for the HUD below are rendered in view.
				glPopMatrix();
				
				// Render the torch mask over the scene.  This is done behind the hud and controls
				[torchMask renderCenteredAtPoint:CGPointMake(240, 160)];
				
				// If we are transporting the player then the fade panel should be drawn under 
				// the HUD
				if (state == kSceneState_TransportingIn || state == kSceneState_TransportingOut) {
					[fadeImage renderAtPoint:CGPointMake(0, 0)];
					
					// To make sure that this gets rendered UNDER the following images we need to get the
					// render manager to render what is currently in the queue.
					[sharedImageRenderManager renderImages];
				}
				
				// Render the hud background
				[hud renderAtPoint:CGPointMake(0, 285)];

				// Render the joypad
				[joypad renderCenteredAtPoint:joypadCenter];
			
				// Render the players avatar
				if (player.energy > 80)
					[avatar[0] renderAtPoint:CGPointMake(0, 285)];
				else if (player.energy > 60)
					[avatar[1] renderAtPoint:CGPointMake(0, 285)];
				else if (player.energy > 40)
					[avatar[2] renderAtPoint:CGPointMake(0, 285)];
				else if (player.energy > 20)
					[avatar[3] renderAtPoint:CGPointMake(0, 285)];
				else if (player.energy > 0)
					[avatar[4] renderAtPoint:CGPointMake(0, 285)];
				
				// Render the players lives
				CGPoint lifeLocation = CGPointMake(40, 290);
				for (int lives=0; lives<3; lives++) {
					if (lives >= player.lives) {
						playerHead.color = Color4fMake(0, 0, 0, 0.35f);
						[playerHead renderAtPoint:lifeLocation];
						lifeLocation.x += 28;
					} else {
						playerHead.color = Color4fMake(1, 1, 1, 1);
						[playerHead renderAtPoint:lifeLocation];
						lifeLocation.x += 28;
					}
				}
				
				// Render the health bar
				[healthBarBackground renderAtPoint:CGPointMake(40, 310)];
				[healthBar renderAtPoint:CGPointMake(40, 310)];

				// Render inventory items
				if (player.inventory1)
					[player.inventory1 render];
				if (player.inventory2)
					[player.inventory2 render];
				if (player.inventory3)
					[player.inventory3 render];
				
				// Render the pickup button
				if (isPlayerOverObject) {
					grabButton.color = Color4fMake(1, 0, 0, 1);
				} else {
					grabButton.color = Color4fMake(1, 1, 1, 1);
				}
				[grabButton renderCenteredAtPoint:CGPointMake(240, 25)];

				// Render the settings button
				[settings renderCenteredAtPoint:settingsButtonCenter];
				
				// Render the score and game time
				[smallFont renderStringJustifiedInFrame:CGRectMake(404, 280, 76, 35) justification:BitmapFontJustification_MiddleRight text:[NSString stringWithFormat:@"S:%06d", score]];
				[smallFont renderStringJustifiedInFrame:CGRectMake(404, 295, 76, 35) justification:BitmapFontJustification_MiddleRight text:[NSString stringWithFormat:@"T: %@", gameTimeToDisplay]];
				
				// Render the name of the current location
				switch (locationName) {
					case kLocationName_Atic:
						[smallFont renderStringJustifiedInFrame:CGRectMake(0, 265, 480, 25) justification:BitmapFontJustification_MiddleCentered text:@"Atic"];
						break;
					case kLocationName_FirstFloor:
						[smallFont renderStringJustifiedInFrame:CGRectMake(0, 265, 480, 25) justification:BitmapFontJustification_MiddleCentered text:@"First Floor"];
						break;
					case kLocationName_GroundFloor:
						[smallFont renderStringJustifiedInFrame:CGRectMake(0, 265, 480, 25) justification:BitmapFontJustification_MiddleCentered text:@"Ground Floor"];
						break;
					case kLocationName_Basement:
						[smallFont renderStringJustifiedInFrame:CGRectMake(0, 265, 480, 25) justification:BitmapFontJustification_MiddleCentered text:@"Basement"];
						break;
					case kLocationName_Caverns:
						[smallFont renderStringJustifiedInFrame:CGRectMake(0, 265, 480, 25) justification:BitmapFontJustification_MiddleCentered text:@"Caverns"];
						break;
						
					default:
						break;
				}
				
				// Render the puse button
				if (state == kSceneState_Running) {
					[pause renderCenteredAtPoint:CGPointMake(386, 303)];
				}

				// If the game is paused then render a transparent quad over the game scene and the word
				// paused in the middle.  Also render the play button rather than the pause button
				if (state == kSceneState_Paused) {
					fadeImage.color = Color4fMake(1, 1, 1, 0.55f);
					[fadeImage renderCenteredAtPoint:CGPointMake(240, 160)];
					[largeFont renderStringJustifiedInFrame:CGRectMake(0, 0, 480, 320) justification:BitmapFontJustification_MiddleCentered text:@"Paused"];
					fadeImage.color = Color4fMake(1, 1, 1, 1);
					[play renderCenteredAtPoint:CGPointMake(386, 303)];
				}
				
				// We only draw the black overlay when we are fading into or out of this scene
				if (state == kSceneState_Loading || state == kSceneState_TransitionOut) {
					[fadeImage renderAtPoint:CGPointMake(0, 0)];
				}
				
				// Render all queued images at this point
				[sharedImageRenderManager renderImages];

// Debug info
#ifdef SCB
				drawRect(pickupButtonBounds);
				drawRect(invItem1Bounds);
				drawRect(invItem2Bounds);
				drawRect(invItem3Bounds);
				drawRect(joypadBounds);
				drawRect(settingsBounds);
				drawRect(pauseButtonBounds);
#endif
				break;
			}
				
			case kSceneState_GameCompleted:
			{
				// Render the game complete background
				[gameComplete renderCenteredAtPoint:CGPointMake(240, 160)];	
				
				// Render the game stats
				CGRect textRectangle = CGRectMake(55, 42, 216, 160);
				NSString *finalScore = [NSString stringWithFormat:@"%06d", score];
				NSString *scoreStat = [NSString stringWithFormat:@"Final Score: %@", finalScore];
				NSString *timeStat = [NSString stringWithFormat:@"Final Time: %@", gameTimeToDisplay];
				[smallFont renderStringJustifiedInFrame:textRectangle justification:BitmapFontJustification_TopLeft text:scoreStat];
				[smallFont renderStringJustifiedInFrame:textRectangle justification:BitmapFontJustification_MiddleLeft text:timeStat];
				[sharedImageRenderManager renderImages];
				break;
			}

			case kSceneState_GameOver:
			{
				// Render the game over background
				[gameOver renderCenteredAtPoint:CGPointMake(240, 160)];
				
				// Render the game stats
				CGRect textRectangle = CGRectMake(55, 42, 216, 150);
				NSString *finalScore = [NSString stringWithFormat:@"%06d", score];
				NSString *scoreStat = [NSString stringWithFormat:@"Final Score: %@", finalScore];
				NSString *timeStat = [NSString stringWithFormat:@"Final Time: %@", gameTimeToDisplay];
				[smallFont renderStringJustifiedInFrame:textRectangle justification:BitmapFontJustification_TopLeft text:scoreStat];
				[smallFont renderStringJustifiedInFrame:textRectangle justification:BitmapFontJustification_MiddleLeft text:timeStat];
				[sharedImageRenderManager renderImages];
				break;
			}
				
			default:
				break;
		}
		
	}
}

#pragma mark -
#pragma mark Save game state

- (void)saveGameState {
	
	SLQLOG(@"INFO - GameScene: Saving game state.");
		
	// Set up the game state path to the data file that the game state will be saved too. 
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	NSString *gameStatePath = [documentsDirectory stringByAppendingPathComponent:@"gameState.dat"];
	
	// Set up the encoder and storage for the game state data
	NSMutableData *gameData;
	NSKeyedArchiver *encoder;
	gameData = [NSMutableData data];
	encoder = [[NSKeyedArchiver alloc] initForWritingWithMutableData:gameData];
	
	// Archive the entities
	[encoder encodeObject:gameEntities forKey:@"gameEntities"];
	
	// Archive the player
	[encoder encodeObject:player forKey:@"player"];
	
	// Archive the players weapon
	[encoder encodeObject:axe forKey:@"weapon"];
	
	// Archive the games doors
	[encoder encodeObject:doors forKey:@"doors"];
	
	// Archive the game objects
	[encoder encodeObject:gameObjects forKey:@"gameObjects"];
	
	// Archive the games timer settings
	NSNumber *savedGameStartTime = [NSNumber numberWithFloat:gameStartTime];
	NSNumber *savedTimeSinceGameStarted = [NSNumber numberWithFloat:timeSinceGameStarted];
	NSNumber *savedScore = [NSNumber numberWithFloat:score];
	[encoder encodeObject:savedGameStartTime forKey:@"gameStartTime"];
	[encoder encodeObject:savedTimeSinceGameStarted forKey:@"timeSinceGameStarted"];
	[encoder encodeObject:savedScore forKey:@"score"];
	[encoder encodeInt:locationName forKey:@"locationName"];
	
	// Finish encoding and write the contents of gameData to file
	[encoder finishEncoding];
	[gameData writeToFile:gameStatePath atomically:YES];
	[encoder release];
	
	// Tell the game controller that a resumed game is available
	sharedGameController.resumedGameAvailable = YES;
}

@end

#pragma mark -
#pragma mark Private implementation

@implementation GameScene (Private)

#pragma mark -
#pragma mark Initialize new game state

- (void)initNewGameState {

	[self initGameContent];
	
	// Set up the players initial locaiton
	player = [[Player alloc] initWithTileLocation:CGPointMake(100, 6)];
	
	// Set the initial location name
	locationName = kLocationName_GroundFloor;
    
	// Now we have loaded the player we need to set up their position in the tilemap
	[self calculatePlayersTileMapLocation];
        
    // Create an instance of the sword which the player is going to through
    axe = [[Axe alloc] initWithTileLocation:CGPointMake(0, 0)];
    
    // Setup ghosts.  The value below defines the total number of ghosts that will spawn anywhere in
    // the map.
    for(int i=0; i<3;i++) {
        Ghost *ghost = [[Ghost alloc] initWithTileLocation:CGPointMake(0, 0)];
        [gameEntities addObject:ghost];
        [ghost release];
    }

    for(int i=0; i<2;i++) {
        Pumpkin *pumpkin = [[Pumpkin alloc] initWithTileLocation:CGPointMake(0, 0)];
        [gameEntities addObject:pumpkin];
        [pumpkin release];
    }
    
    for(int i=0; i<1;i++) {
        Vampire *vampire = [[Vampire alloc] initWithTileLocation:CGPointMake(0, 0)];
        [gameEntities addObject:vampire];
        [vampire release];
    }
    
    for(int i=0; i<3;i++) {
        Bat *bat = [[Bat alloc] initWithTileLocation:CGPointMake(0, 0)];
        [gameEntities addObject:bat];
        [bat release];
    }
    
    for(int i=0; i<2;i++) {
        Zombie *zombie = [[Zombie alloc] initWithTileLocation:CGPointMake(0, 0)];
        [gameEntities addObject:zombie];
        [zombie release];
    }
    
    for(int i=0; i<1;i++) {
        Witch *witch = [[Witch alloc] initWithTileLocation:CGPointMake(0, 0)];
        [gameEntities addObject:witch];
        [witch release];
    }
    
    for(int i=0; i<1;i++) {
        Frank *frank = [[Frank alloc] initWithTileLocation:CGPointMake(0, 0)];
        [gameEntities addObject:frank];
        [frank release];
    }
	
	// Initialize the game items.  This is only done when initializing a new game as 
	// this information is loaded when a resumed game is started.
	[self initItems];
	
	// Init the localDoors array
	[self initLocalDoors];
}

                                    
- (void)loadGameState {
	
	[self initGameContent];

    // Set up the file manager and documents path
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSMutableData *gameData;
    NSKeyedUnarchiver *decoder;
    
    // Check to see if the ghosts.dat file exists and if so load the contents into the
    // entities array
    NSString *documentPath = [documentsDirectory stringByAppendingPathComponent:@"gameState.dat"];
    gameData = [NSData dataWithContentsOfFile:documentPath];

    decoder = [[NSKeyedUnarchiver alloc] initForReadingWithData:gameData];

    SLQLOG(@"INFO - GameScene: Loading saved player data.");
    player = [[decoder decodeObjectForKey:@"player"] retain];
	[self calculatePlayersTileMapLocation];

	SLQLOG(@"INFO - GameScene: Loading saved weapon data.");
    axe = [[decoder decodeObjectForKey:@"weapon"] retain];
	
	SLQLOG(@"INFO - GameScene: Loading saved entity data.");
	if (gameEntities)
		[gameEntities release];
    gameEntities = [[decoder decodeObjectForKey:@"gameEntities"] retain];

	SLQLOG(@"INFO - GameScene: Loading saved game object data.");
	if (gameObjects)
		[gameObjects release];
	gameObjects = [[decoder decodeObjectForKey:@"gameObjects"] retain];

	SLQLOG(@"INFO - GameScene: Loading saved door data.");
	if (doors)
		[doors release];
    doors = [[decoder decodeObjectForKey:@"doors"] retain];
    
	SLQLOG(@"INFO - GameScene: Loading saved game duration.");
    timeSinceGameStarted = [[decoder decodeObjectForKey:@"timeSinceGameStarted"] floatValue];
	
	SLQLOG(@"INFO - GameScene: Loading saved game score.");
	score = [[decoder decodeObjectForKey:@"score"] floatValue];
	
	SLQLOG(@"INFO - GameScene: Loading location name.");
	locationName = [decoder decodeIntForKey:@"locationName"];
    
    SLQLOG(@"INFO - GameScene: Loading game time data.");

	// We have finishd decoding the objects and retained them so we can now release the
	// decoder object
	[decoder release];

	// Init the localDoors array
	[self initLocalDoors];
}

- (void)initScene {

	// Game objects
	doors = [[NSMutableArray alloc] init]; 
	gameEntities = [[NSMutableArray alloc] init];
	portals = [[NSMutableArray alloc] init];
	gameObjects = [[NSMutableArray alloc] init];
	localDoors = [[NSMutableArray alloc] init];
	
    // Get the master sprite sheet we are going to get all of our other graphical items from.  Having a single texture with all
    // the graphics will help reduce the number of textures bound per frame and therefor performance
    PackedSpriteSheet *masterSpriteSheet = [PackedSpriteSheet packedSpriteSheetForImageNamed:@"atlas.png" controlFile:@"coordinates" imageFilter:GL_LINEAR];
	
    // Initialize the fonts needed for the game
    smallFont = [[BitmapFont alloc] initWithFontImageNamed:@"franklin16.png" controlFile:@"franklin16" scale:Scale2fMake(1.0f, 1.0f) filter:GL_LINEAR];
	largeFont = [[BitmapFont alloc] initWithFontImageNamed:@"bookAntiqua32.png" controlFile:@"bookAntiqua32" scale:Scale2fMake(1.0f, 1.0f) filter:GL_LINEAR];
    
    // In game GUI graphics
    hud = [[masterSpriteSheet imageForKey:@"hudbar.png"] retain];
	hud.color = Color4fMake(1, 1, 1, 0.25f);
	
    // In game avatar that shows the players health
    avatarSheet = [SpriteSheet spriteSheetForImage:[masterSpriteSheet imageForKey:@"UIface_horizontal.png"] sheetKey:@"UIface_horizontal.png" spriteSize:CGSizeMake(35, 35) spacing:0 margin:0];
    avatar[0] = [avatarSheet spriteImageAtCoords:CGPointMake(0, 0)];
    avatar[1] = [avatarSheet spriteImageAtCoords:CGPointMake(1, 0)];
    avatar[2] = [avatarSheet spriteImageAtCoords:CGPointMake(2, 0)];
    avatar[3] = [avatarSheet spriteImageAtCoords:CGPointMake(3, 0)];
    avatar[4] = [avatarSheet spriteImageAtCoords:CGPointMake(4, 0)];
	
	// Players lives image
	playerHead = [[masterSpriteSheet imageForKey:@"playerHead.png"] retain];
	
	// Main door images and exit rectangle
	openMainDoor = [[masterSpriteSheet imageForKey:@"mainDoorOpen.png"] retain];
	closedMainDoor = [[masterSpriteSheet imageForKey:@"mainDoorClosed.png"] retain];
	exitBounds = CGRectMake(3960, 0, 80, 40);
	gameComplete = [[Image alloc] initWithImageNamed:@"ending.png" filter:GL_LINEAR];
    
    // In game pause button and pickup/drop buttons.  The bounds for the pickup/drop button
	// are defined when checking the joypad as the button is calculated based on the location
	// of the joypad
	pickupButtonBounds = CGRectMake(200, 0, 75, 50);
	invItem1Bounds = CGRectMake(155, 273, 50, 50);
	invItem2Bounds = CGRectMake(215, 273, 50, 50);
	invItem3Bounds = CGRectMake(275, 273, 50, 50);
	
	// Play button
	play = [[masterSpriteSheet imageForKey:@"play.png"] retain];
	play.color = Color4fMake(1, 1, 1, 1);
	
	// Pause button
	pause = [[masterSpriteSheet imageForKey:@"pause.png"] retain];
	pause.color = Color4fMake(0, 0, 0, 0.35f);
    pauseButtonBounds = CGRectMake(360, 280, 50, 40);
	
	// Settings button
	settings = [[masterSpriteSheet imageForKey:@"gear.png"] retain];
	settings.color = Color4fMake(1, 1, 1, 0.25f);
	settingsButtonCenter = CGPointMake(430, 15);
	settingsButtonSize = CGSizeMake(25, 25);
	
    // In game torch overlay
    torchMask = [[masterSpriteSheet imageForKey:@"torch.png"] retain];
    [torchMask setColor:Color4fMake(1.0f, 1.0f, 1.0f, 1.0f)];
    
    // Overlay used to fade the game scene
    fadeImage = [[Image alloc] initWithImageNamed:@"allBlack.png" filter:GL_NEAREST];
	fadeImage.scale = Scale2fMake(480, 320);
	
	// healthbar
	healthBar = [[masterSpriteSheet imageForKey:@"healthbar.png"] retain];
	healthBarBackground = [[healthBar imageDuplicate] retain];
	[healthBar setImageSizeToRender:CGSizeMake(100, 75)];
	[healthBarBackground setImageSizeToRender:CGSizeMake(100, 75)];
	healthBarBackground.color = Color4fMake(0, 0, 0, 0.35);
	
	// Grab button image
	grabButton = [[masterSpriteSheet imageForKey:@"grabButton.png"] retain];
	
    // Joypad setup
	joypadCenter = CGPointMake(50, 50);
	joypadRectangleSize = CGSizeMake(40, 40);
	
    joypad = [[masterSpriteSheet imageForKey:@"joypad1.png"] retain];
    joypad.color = Color4fMake(1.0f, 1.0f, 1.0f, 0.10f);
	
	// Game Over & loading image
	gameOver = [[Image alloc] initWithImageNamed:@"GameOver.png" filter:GL_LINEAR];
    
	// Set up the game score and timers
	score = 0;
	timeSinceGameStarted = 0;
    gameStartTime = CACurrentMediaTime();
	gameTimeToDisplay = @"000.00";
	
	// Set up flags
	isWinMusicPlaying = NO;
	isLoseMusicPlaying = NO;
		
	// Set the players last position to 0 so that in the update method the local doors are calculated when the game
	// first starts
	playersLastLocation = CGPointMake(0,0);
}

- (void)initGameContent {
	// Initialize the scenes tile map
	[self initTileMap];
    [self initCollisionMapAndDoors];
    [self initPortals];	
}

- (void)initSound {
    
    // Set the listener to the middle of the screen by default.  This will be changed as the player moves around the map
    [sharedSoundManager setListenerPosition:CGPointMake(240, 160)];
    
    // Initialize the sound effects
    [sharedSoundManager loadSoundWithKey:@"doorSlam" soundFile:@"doorSlam.caf"];
    [sharedSoundManager loadSoundWithKey:@"doorOpen" soundFile:@"doorOpen.caf"];
    [sharedSoundManager loadSoundWithKey:@"pop" soundFile:@"pop.caf"];
    [sharedSoundManager loadSoundWithKey:@"hitWall" soundFile:@"hitwall.caf"];
    [sharedSoundManager loadSoundWithKey:@"eatfood" soundFile:@"eatfood.caf"];
	[sharedSoundManager loadSoundWithKey:@"scream" soundFile:@"scream.caf"];
	[sharedSoundManager loadSoundWithKey:@"spell" soundFile:@"spell.caf"];
	[sharedSoundManager loadSoundWithKey:@"hurt" soundFile:@"hurt.caf"];
    
    // Initialize the background music
    [sharedSoundManager loadMusicWithKey:@"ingame" musicFile:@"ingame.mp3"];
	[sharedSoundManager loadMusicWithKey:@"loseIntro" musicFile:@"loseIntro.mp3"];
	[sharedSoundManager loadMusicWithKey:@"loseLoop" musicFile:@"loseLoop.mp3"];
	[sharedSoundManager loadMusicWithKey:@"winIntro" musicFile:@"winIntro.mp3"];
	[sharedSoundManager loadMusicWithKey:@"winLoop" musicFile:@"winLoop.mp3"];
	[sharedSoundManager loadMusicWithKey:@"voice" musicFile:@"voice.wav"];
	[sharedSoundManager addToPlaylistNamed:@"win" track:@"winIntro"];
	[sharedSoundManager addToPlaylistNamed:@"win" track:@"winLoop"];
	[sharedSoundManager addToPlaylistNamed:@"lose" track:@"loseIntro"];
	[sharedSoundManager addToPlaylistNamed:@"lose" track:@"loseLoop"];
	[sharedSoundManager addToPlaylistNamed:@"inGame" track:@"voice"];
	[sharedSoundManager addToPlaylistNamed:@"inGame" track:@"ingame"];
	sharedSoundManager.loopLastPlaylistTrack = YES;
}


- (void)checkJoypadSettings {

    // If the joypad is marked as being on the left the set the joypads center left, otherwise,
	// you guessed it, set the joypad center to the right.  This also adjusts the location of
	// the settings button which needs to also be moved
	if (sharedGameController.joypadPosition == 0) {
        joypadCenter.x = 50;
		settingsButtonCenter.x = 465;
		settingsBounds = CGRectMake(430, 0, 50, 50);
    } else if (sharedGameController.joypadPosition == 1) {
	    joypadCenter.x = 430;
		settingsButtonCenter.x = 15;
		settingsBounds = CGRectMake(0, 0, 50, 50);
    }
	
	// Calculate the rectangle that we check for touches to know someone has touched the joypad
	joypadBounds = CGRectMake(joypadCenter.x - joypadRectangleSize.width, 
						joypadCenter.y - joypadRectangleSize.height, 
						joypadRectangleSize.width * 2, 
						joypadRectangleSize.height * 2);
}

- (void)initPortals {
    
    // Get the object groups that were found in the tilemap
    NSMutableDictionary *portalObjects = castleTileMap.objectGroups;
    
    // Calculate the height of the tilemap in pixels.  We also add an extra tile to the height
    // so that objects pixel location is correct.  This is needed as the tile map has a zero
    // index which means we actually loose a tile when calculating a pixel position within the
    // map
    float tileMapPixelHeight = (kTile_Height * (castleTileMap.mapHeight - 1));
    
    // Loop through all objects in the object group called Portals
    NSMutableDictionary *objects = [[portalObjects objectForKey:@"Portals"] objectForKey:@"Objects"];
    for (NSString *objectKey in objects) {
        
        // Get the location of the portal
        float portal_x = [[[[objects objectForKey:objectKey] 
                            objectForKey:@"Attributes"] 
                           objectForKey:@"x"] floatValue] / kTile_Width;
        
        // As the tilemap coordinates have been reversed on the y-axis, we need to also reverse
        // y-axis pixel locaiton for objects.  This is done by subtracting the objects current
        // y value from the full pixel height of the tilemap
        float portal_y = (tileMapPixelHeight - [[[[objects objectForKey:objectKey] 
                                                  objectForKey:@"Attributes"] 
                                                 objectForKey:@"y"] floatValue]) / kTile_Height;
        
        // Get the location to where the portal will transport the player
        float dest_x = [[[[objects objectForKey:objectKey]
                          objectForKey:@"Properties"] 
                         objectForKey:@"dest_x"] floatValue];
        
        float dest_y = [[[[objects objectForKey:objectKey]
                          objectForKey:@"Properties"]
                         objectForKey:@"dest_y"] floatValue];
        
		// Get the name of the destination this portal takes you too
		uint destinationName = [[[[objects objectForKey:objectKey]
								  objectForKey:@"Properties"]
								 objectForKey:@"locationName"] intValue];
		
        // Create a portal instance and add it to the portals array
        Portal *portal = [[Portal alloc] initWithTileLocation:CGPointMake(portal_x, portal_y) beamLocation:CGPointMake(dest_x, dest_y)];
        portal.state = kEntityState_Alive;
		portal.locationName = destinationName;
        [portals addObject:portal];
        [portal release];
        portal = nil;
    }
}

- (void)initItems {
    // Get the object groups that were found in the tilemap
    NSMutableDictionary *objectGroups = castleTileMap.objectGroups;
    
    // Calculate the height of the tilemap in pixels.  All tile locations are zero indexed
	// so we need to reduce the mapHeight by 1 to calculate the pixels correctly.
    // so that objects pixel location is correct.
    float tileMapPixelHeight = (kTile_Height * (castleTileMap.mapHeight - 1));
    
    // Loop through all objects in the object group called Game Objects
    NSMutableDictionary *objects = [[objectGroups objectForKey:@"Game Objects"] objectForKey:@"Objects"];
    
    for (NSString *objectKey in objects) {
        
        // Get the x location of the object
        float object_x = [[[[objects objectForKey:objectKey] 
                            objectForKey:@"Attributes"] 
                           objectForKey:@"x"] floatValue] / kTile_Width;
        
        // As the tilemap coordinates have been reversed on the y-axis, we need to also reverse
        // y-axis pixel location for objects.  This is done by subtracting the objects current
        // y value from the full pixel height of the tilemap
        float object_y = (tileMapPixelHeight - [[[[objects objectForKey:objectKey] 
                                                  objectForKey:@"Attributes"] 
                                                 objectForKey:@"y"] floatValue]) / kTile_Height;
        
        // Get the type of the object
        uint type = [[[[objects objectForKey:objectKey]
                          objectForKey:@"Attributes"] 
                         objectForKey:@"type"] intValue];

        // Get the subtype of the object
        uint subType = [[[[objects objectForKey:objectKey]
                       objectForKey:@"Properties"] 
                      objectForKey:@"subtype"] intValue];
        
        // Based on the type and subtype of the object in the map create the correct object instance
        // and add it to the game objects array
        switch (type) {
            case kObjectType_Energy:
            {
				EnergyObject *object = [[EnergyObject alloc] initWithTileLocation:CGPointMake(object_x, object_y) type:type subType:subType];
				[gameObjects addObject:object];
				[object release];
				break;
            }
                
            case kObjectType_Key:
			{
				KeyObject *key = [[KeyObject alloc] initWithTileLocation:CGPointMake(object_x, object_y) type:type subType:subType];
				[gameObjects addObject:key];
				[key release];
                break;
			}
                
            case kObjectType_General:
			{
				switch (subType) {
					case kObjectSubType_ParchmentTop:
					case kObjectSubType_ParchmentMiddle:
					case kObjectSubType_ParchmentBottom:
					{
						ParchmentObject *object = [[ParchmentObject alloc] initWithTileLocation:CGPointMake(object_x,object_y) type:type subType:subType];
						[gameObjects addObject:object];
						[object release];
						break;
					}

					case kObjectSubType_Grave:
					case kObjectSubType_TopLamp:
					case kObjectSubType_LeftLamp:
					case kObjectSubType_BottomLamp:
					case kObjectSubType_RightLamp:
					case kObjectSubType_Skull:
					case kObjectSubType_Mushroom:
					{
						MapObject *object = [[MapObject alloc] initWithTileLocation:CGPointMake(object_x, object_y) type:type subType:subType];
						[gameObjects addObject:object];
						[object release];
						break;
					}
					
					default:
						break;
				}
             }
						
            default:
                break;
        }
    }
}

- (void)initTileMap {
    
    // Create a new instance of TiledMap
    castleTileMap = [[TiledMap alloc] initWithFileName:@"slqtsor" fileExtension:@"tmx"];
    
    // Grab the map width and height in tiles
    tileMapWidth = [castleTileMap mapWidth];
    tileMapHeight = [castleTileMap mapHeight];
    
    // Calculate how many tiles it takes to fill the screen for width and height
    screenTilesWide = screenBounds.size.height / kTile_Width;
    screenTilesHeight = screenBounds.size.width / kTile_Height;
    
    // The player is going to be in the middle of the screen, so calculate the offset in tiles from the player
    // to the left edge and bottom of the screen.
    bottomOffsetInTiles = screenTilesHeight / 2;
    leftOffsetInTiles = screenTilesWide / 2;
}

- (void)initCollisionMapAndDoors {
    
    // Build a map of blocked locations within the tilemap.  This information is held on a layer called Collision
    // within the tilemap
    SLQLOG(@"INFO - GameScene: Creating tilemap collision array and doors.");
    
    // Grab the layer index for the layer in the tile map called Collision
    int collisionLayerIndex = [castleTileMap layerIndexWithName:@"Collision"];
    Door *door = nil;
    
    // Loop through the map tile by tile
    Layer *collisionLayer = [[castleTileMap layers] objectAtIndex:collisionLayerIndex];
    for(int yy=0; yy < castleTileMap.mapHeight; yy++) {
        for(int xx=0; xx < castleTileMap.mapWidth; xx++) {
            
            // Grab the global tile id from the tile map for the current location
            int globalTileID = [collisionLayer globalTileIDAtTile:CGPointMake(xx, yy)];
            
            // If the global tile ID is the blocking tile image then this location is blocked.  If it is a door object
            // then a door is created and placed in the doors array.  The value below is the tileid from the tileset used in the 
			// tile map.  If this tile is present in the collision layer then we mark that tile as blocked.
            if(globalTileID == kBlockedTileGloablID) {
                blocked[xx][yy] = YES;
            } else  {
                
                // If the game is being resumed, then we do not need to load the doors array
                if (!sharedGameController.shouldResumeGame) {
                    // Check to see if the tileid for the current tile is a door tile.  If not then move on else check the type
					// of the door and create a door instance.  If the tile map sprite sheet changes then these numbers need to be
					// checked.  Also this assumes that the door tile are contiguous in the sprite sheet
					if (globalTileID >= kFirstDoorTileGlobalID && globalTileID <= kLastDoorTileGlobalID) {
						int doorType = [[castleTileMap tilePropertyForGlobalTileID:globalTileID key:@"type" defaultValue:@"-1"] intValue];
						if (doorType != -1) {
							// Create a new door instance of the correct type.  As we create the door we set the doors array
							// index to be its index in the doors array.  At this point we have not actually added the door to 
							// the array so we can use the current array count which will give us the correct number
							door = [[Door alloc] initWithTileLocation:CGPointMake(xx, yy) type:doorType arrayIndex:[doors count]];
							[doors addObject:door];
							[door release];
						}
					}
                }
            }
        }
    }
	SLQLOG(@"INFO - GameScene: Finished constructing collision array and doors.");
}

- (void)calculatePlayersTileMapLocation {
	// Round the players tile location
	playerTileX = (int) player.tileLocation.x;
    playerTileY = (int) player.tileLocation.y;

    // Calculate the players tile x and y offset.  This allows us to keep the player in the middle of
	// the screen and have the map render correctly under the player.  This information is used when
	// rendering the tile map layers in the render method
	playerTileOffsetX = (int) ((playerTileX - player.tileLocation.x) * kTile_Width);
    playerTileOffsetY = (int) ((playerTileY - player.tileLocation.y) * kTile_Height);
}

- (void)initLocalDoors {
	// Calculate the tile bounds around the player. We clamp the possbile values to between
	// 0 and the width/height of the tile map.  We remove 1 from the width and height
	// as the tile map is zero indexed in the game.  These values can then be used when
	// checking if objects, portals or doors should be updated
	int minScreenTile_x = CLAMP(player.tileLocation.x - 8, 0, kMax_Map_Width-1);
	int maxScreenTile_x = CLAMP(player.tileLocation.x + 8, 0, kMax_Map_Width-1);
	int minScreenTile_y = CLAMP(player.tileLocation.y - 6, 0, kMax_Map_Height-1);
	int maxScreenTile_y = CLAMP(player.tileLocation.y + 6, 0, kMax_Map_Height-1);
	
	// Populate the localDoors array with any doors that are found around the player.  This allows
	// us to reduce the number of doors we are rendering and updating in any single frame.  We only
	// perform this check if the player has moved from one tile to another on the tile map to save cycles
	if ((int)player.tileLocation.x != (int)playersLastLocation.x || (int)player.tileLocation.y != (int)playersLastLocation.y) {
		
		// Clear the localDoors array as we are about to populate it again based on the 
		// players new position
		[localDoors removeAllObjects];
		
		// Find doors that are close to the player and add them to the localDoors loop.  Layer 3 in the 
		// tile map holds the door information
		Layer *layer = [[castleTileMap layers] objectAtIndex:2];
		for (int yy=minScreenTile_y; yy < maxScreenTile_y; yy++) {
			for (int xx=minScreenTile_x; xx < maxScreenTile_x; xx++) {
				
				// If the value property for this tile is not -1 then this must be a door and
				// we should add it to the localDoors array
				if ([layer valueAtTile:CGPointMake(xx, yy)] > -1) {
					int index = [layer valueAtTile:CGPointMake(xx, yy)];
					[localDoors addObject:[NSNumber numberWithInt:index]];
				}
			}
		}
	}
}

- (void)deallocResources {

	// Release the images
	[fadeImage release];
	[gameOver release];
	[gameComplete release];
	[pauseButton release];
	[pickupButton release];
	[torchMask release];
	[openMainDoor release];
	[closedMainDoor release];
	[hud release];
	[healthBar release];
	[healthBarBackground release];
	[joypad release];
	[play release];
	[pause release];

	// Release fonts
	[smallFont release];
	[largeFont release];

	// Release game entities
	[doors release];
	[gameEntities release];
	[axe release];
	[localDoors release];
	[gameObjects release];
	[portals release];
	[castleTileMap release];
	[player release];

	// Release sounds
	[sharedSoundManager removeSoundWithKey:@"doorSlam"];
	[sharedSoundManager removeSoundWithKey:@"doorOpen"];
	[sharedSoundManager removeSoundWithKey:@"pop"];
	[sharedSoundManager removeSoundWithKey:@"hitWall"];
	[sharedSoundManager removeSoundWithKey:@"eatfood"];
	[sharedSoundManager removeSoundWithKey:@"scream"];
	[sharedSoundManager removeSoundWithKey:@"spell"];
	[sharedSoundManager removeSoundWithKey:@"hurt"];
	[sharedSoundManager removeMusicWithKey:@"ingame"];
	[sharedSoundManager removeMusicWithKey:@"winIntro"];
	[sharedSoundManager removeMusicWithKey:@"winLoop"];
	[sharedSoundManager removeMusicWithKey:@"loseIntro"];
	[sharedSoundManager removeMusicWithKey:@"loseLoop"];
	[sharedSoundManager removeMusicWithKey:@"voice"];
	[sharedSoundManager removePlaylistNamed:@"win"];
	[sharedSoundManager removePlaylistNamed:@"lose"];

}
@end

