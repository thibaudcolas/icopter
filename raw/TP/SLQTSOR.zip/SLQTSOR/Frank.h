//
//  Frank.h
//  SLQTSOR
//
//  Created by Mike Daley on 10/11/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//

#import "AbstractEntity.h"

@interface Frank : AbstractEntity {

}

@end
