//
//  Witch.h
//  SLQTSOR
//
//  Created by Mike Daley on 10/11/2009.
//  Copyright 2009 Michael Daley. All rights reserved.
//

#import "AbstractEntity.h"

enum {
	kEntityAIState_Roaming,
	kEntityAIState_Chasing
};

@interface Witch : AbstractEntity {

	uint entityAIState;	// Holds the current AI state enum for the entity
	
}

@end
